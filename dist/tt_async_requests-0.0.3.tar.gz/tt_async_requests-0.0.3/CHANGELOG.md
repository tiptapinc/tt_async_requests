## v0.0.3

* only log failed asyncRequests

## v0.0.2

* relaxed success requirements for sending to accept any result code less than 400

## v0.0.1:

* Initial release
